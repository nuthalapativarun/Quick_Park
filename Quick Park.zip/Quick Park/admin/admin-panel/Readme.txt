﻿In this Sample
-----------------------------
Added new pages
  Playlists.html - Added dynamic accordions
TemplatePage.html - Updated to reflect new changes

Added Font Awesome